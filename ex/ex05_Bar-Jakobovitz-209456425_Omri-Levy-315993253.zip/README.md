# Exercise 5 – Modeling with WebGL
* Important Note since we wanted to add the sun and to make a better view of the scene, we change the camera location to (0,0,120) instead of (0,0,5)
* We added the sun as an additional planet and it is placed in the origin.
* To both the sun and the planet we added textures (base on recitation 10).
* Another wing was added to the spaceship in order to make it look more symmetrically. (so 4 wings in total)
* We added an additional animation (toggle on with '4' keyboard key) which make our planet (Earth) rotate around iteself and around the sun.
 and also the sun rotate around itself.
* We added a Cube with the logo of Maccabi Haifa, the best team in the Israel. And if they play aborad at france or germany so they are the best team in the world. 


